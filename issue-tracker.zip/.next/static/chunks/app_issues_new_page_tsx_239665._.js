(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_issues_new_page_tsx_239665._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_issues_new_page_tsx_239665._.js",
  "chunks": [
    "static/chunks/_6c0db6._.js"
  ],
  "source": "dynamic"
});
