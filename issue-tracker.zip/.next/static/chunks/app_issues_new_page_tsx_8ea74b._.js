(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_issues_new_page_tsx_8ea74b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_issues_new_page_tsx_8ea74b._.js",
  "chunks": [
    "static/chunks/node_modules_d7a1ff._.js",
    "static/chunks/app_b83e1f._.js",
    "static/chunks/node_modules_easymde_dist_easymde_min_44c41b.css",
    "static/chunks/node_modules_react-simplemde-editor_dist_SimpleMdeReact_mjs_6f0ab2._.js"
  ],
  "source": "dynamic"
});
