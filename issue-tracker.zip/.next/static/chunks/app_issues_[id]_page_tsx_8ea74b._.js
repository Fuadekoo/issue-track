(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_issues_[id]_page_tsx_8ea74b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_issues_[id]_page_tsx_8ea74b._.js",
  "chunks": [
    "static/chunks/app_issues_[id]_page_tsx_284c8b._.js"
  ],
  "source": "dynamic"
});
