(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_61af54._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_61af54._.js",
  "chunks": [
    "static/chunks/[root of the server]__9e9e2f._.css",
    "static/chunks/node_modules_react-icons_ai_index_mjs_b8cfc3._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_@radix-ui_themes_dist_esm_7c59e6._.js",
    "static/chunks/node_modules_cc0718._.js",
    "static/chunks/app_81e4c2._.js"
  ],
  "source": "dynamic"
});
