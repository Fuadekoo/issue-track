(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_testData_users_page_tsx_8ea74b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_testData_users_page_tsx_8ea74b._.js",
  "chunks": [
    "static/chunks/app_testData_users_page_tsx_5cd1ab._.js"
  ],
  "source": "dynamic"
});
