(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_issues_page_tsx_8ea74b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_issues_page_tsx_8ea74b._.js",
  "chunks": [
    "static/chunks/_2c8db8._.js",
    "static/chunks/node_modules_react-loading-skeleton_dist_skeleton_635fca.css"
  ],
  "source": "dynamic"
});
