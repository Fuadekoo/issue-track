(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_issues_[id]_loading_jsx_8ea74b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_issues_[id]_loading_jsx_8ea74b._.js",
  "chunks": [
    "static/chunks/app_issues_[id]_loading_jsx_b8154b._.js"
  ],
  "source": "dynamic"
});
